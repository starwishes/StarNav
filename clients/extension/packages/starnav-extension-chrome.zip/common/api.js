export class ApiError extends Error {
  constructor(message, options = {}) {
    super(message)
    this.name = 'ApiError'
    this.status = Number(options.status || 0)
    this.payload = options.payload
  }
}

export function unwrapApiPayload(payload) {
  if (payload && typeof payload === 'object') {
    if (payload.data !== undefined) {
      return payload.data
    }

    if (payload.content !== undefined) {
      return payload.content
    }
  }

  return payload
}

export function mergeApiPayload(payload) {
  const base = payload && typeof payload === 'object' ? payload : {}
  const unwrapped = unwrapApiPayload(payload)

  if (unwrapped && typeof unwrapped === 'object' && !Array.isArray(unwrapped)) {
    return {
      ...base,
      ...unwrapped
    }
  }

  return base
}

export function getApiField(payload, field, fallback) {
  if (payload && typeof payload === 'object' && field in payload) {
    return payload[field]
  }

  const unwrapped = unwrapApiPayload(payload)
  if (unwrapped && typeof unwrapped === 'object' && field in unwrapped) {
    return unwrapped[field]
  }

  return fallback
}

export function extractApiErrorMessage(payload, status) {
  if (payload && typeof payload === 'object') {
    if (typeof payload.error === 'string' && payload.error) {
      return payload.error
    }

    if (typeof payload.message === 'string' && payload.message) {
      return payload.message
    }
  }

  return typeof status === 'number' ? `HTTP Error ${status}` : 'Request failed'
}

export async function readJsonBody(response, fallback = {}) {
  try {
    return await response.json()
  } catch {
    return fallback
  }
}
